import React from 'react';
import RecogerLosPlatos from './verTarea/recogerlosplatos.png';
import PonerLaMesa from './verTarea/ponerlamesa.png';
import MesaPuesta  from './verTarea/mesapuesta.png';

export default function tareas(){

    const nomTarea= "Poner la mesa";
    const descrip = "Debes poner la mesa. Para ello, ve a la cocina, coge los materiales necesarios y llévalos al comedor. A continuación, encontrarás los pasos que debes seguir para completar la tarea.";

    const PASOS = [
    {
        title: "Paso 1: ",
        data: ["Coge de la cocina el mantel, los platos, los cubiertos, los vasos y las servilletas."],
        imagen: RecogerLosPlatos
    },
    {
        title: "Paso 2: ",
        data: ["Lleva todo el material al comedor y coloca correctamente en cada lugar los materiales.."],
        imagen: PonerLaMesa
    },
    {
        title: "Paso 3: ",
        data: ["Siéntate y espera a que la comida esté hecha."],
        imagen: MesaPuesta
    }
    ]

    return [nomTarea, descrip, PASOS];
}